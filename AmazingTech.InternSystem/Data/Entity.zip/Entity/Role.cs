﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AmazingTech.InternSystem.Data.Entity
{
    public class Role : IdentityRole
    {
        [Key]
        public string Id { get; set; }
        public Roles Name { get; set; }
        public virtual ICollection<User> Users { get; set; } = new List<User>();
    }

    public class Roles
    {
        public const string ADMIN = "Admin";
        public const string HR = "Hr";
        public const string SCHOOL = "School";
        public const string MENTOR = "Mentor";
        public const string INTERN = "Intern";
    }
}
